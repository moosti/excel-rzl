<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
$botToken = '7060624258:AAGe04QDTKI-7VaRtPoYbpkZc0Mr0Bj1ngo';
$dbUserName = 'qqbangbang';
$dbPassword = 'vTVZAlSu#7iNPIQM@sio';
$dbName = 'wiziwizi';
$botUrl = 'https://helper.payabapp.ir:11500/wizwizxui-timebot/';
$admin = '39998887';